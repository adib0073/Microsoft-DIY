﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Net.Http;// NuGet/add/install
using Windows.Web.Http;// NuGet/add/install
using Windows.Web.Http.Headers;// NuGet/add/install
using Newtonsoft.Json.Linq;// NuGet/add/install
using System.Threading.Tasks;
using Windows.ApplicationModel.Core;
using Windows.UI.Core;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace IoTConnector
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private double temperature = 0.0;
        public MainPage()
        {
            this.InitializeComponent();
            
            Task.Run(
                async ()=>{
                    while(true)
                    {
                        var message = await AzureIoTHub.ReceiveCloudToDeviceMessageAsync();
                        await CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(CoreDispatcherPriority.High, () => {
                            textBlock.Text += Environment.NewLine + message;
                            
                           
                        });
                    }
                }
            );
        }
        private void button_Click(object sender, RoutedEventArgs e)
        {
            GetRequest();
            Task.Run(async () => { await AzureIoTHub.SendDeviceToCloudMessageAsync(temperature); });
        }
        string apiKey = "3f01b78377014eb1b767ea6d5a9de591";//http://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b6907d289e10d714a6e88b30761fae22
        string URL = "api.openweathermap.org/data/2.5/forecast?id=1269843&APPID=3f01b78377014eb1b767ea6d5a9de591";

        public async void GetRequest()
        {
            
            Uri geturi = new Uri("http://api.openweathermap.org/data/2.5/forecast?id=1269843&APPID=3f01b78377014eb1b767ea6d5a9de591"); //replace your url 
            System.Net.Http.HttpClient client = new System.Net.Http.HttpClient();//
            System.Net.Http.HttpResponseMessage responseGet = await client.GetAsync(geturi);//
            string response = await responseGet.Content.ReadAsStringAsync();//
            JObject jsonData = JObject.Parse(response);//
            if (jsonData.SelectToken("cod").ToString() == "200")//
            {
                temperature = ((double)jsonData.SelectToken("list")[0].SelectToken("main").SelectToken("temp") - 273+ (double)jsonData.SelectToken("list").Last().SelectToken("main").SelectToken("temp") - 273)/2;//
            }
        }

        /*public async void POSTreq()
{
   Uri requestUri = new Uri("https://www.userauth");//replace your Url 
   dynamic dynamicJson = new ExpandoObject();
   dynamicJson.username = "sureshmit55@gmail.com".ToString();
   dynamicJson.password = "9442921025";
   string json = "";
   json = Newtonsoft.Json.JsonConvert.SerializeObject(dynamicJson);
   var objClint = new System.Net.Http.HttpClient();
   System.Net.Http.HttpResponseMessage respon = await objClint.PostAsync(requestUri, new StringContent(json, System.Text.Encoding.UTF8, "application/json"));
   string responJsonText = await respon.Content.ReadAsStringAsync();
}*/
    }
   
}
